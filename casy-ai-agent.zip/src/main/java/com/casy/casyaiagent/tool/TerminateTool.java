package com.casy.casyaiagent.tool;

import org.springframework.ai.tool.annotation.Tool;

/**
 * 终止工具，让智能体可以自行决定任务结束
 *
 * @author linlin
 */
public class TerminateTool {

    @Tool(description = """  
            Terminate the interaction when the request is met OR if the assistant cannot proceed further with the task.  
            When you have finished all the tasks, call this tool to end the work.
            After calling this tool, the system will automatically generate a final summary for the user.
            """)
    public String doTerminate() {
        return "任务结束";
    }
}
