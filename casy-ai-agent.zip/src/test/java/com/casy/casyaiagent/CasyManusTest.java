package com.casy.casyaiagent;

import com.casy.casyaiagent.agent.CasyManus;
import jakarta.annotation.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author Administrator
 * @version 1.0
 * @description: TODO
 * @date 2026/3/30 21:51
 */
@SpringBootTest
class CasyManusTest {

    @Resource
    private CasyManus casyManus;

    @Test
    void run() {
        String userPrompt = """  
                我的另一半居住在上海静安区，请帮我找到 5 公里内合适的约会地点,
                并结合一些网络图片，制定一份详细的约会计划,
                并以 PDF 格式输出, PDF中要显示这些图片""";
        String answer = casyManus.run(userPrompt);
        Assertions.assertNotNull(answer);
    }
}