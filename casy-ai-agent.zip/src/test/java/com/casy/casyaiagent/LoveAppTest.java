package com.casy.casyaiagent;

import com.casy.casyaiagent.ai.LoveApp;
import jakarta.annotation.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;

@SpringBootTest
class LoveAppTest {

    @Resource
    private LoveApp loveApp;

    @Test
    void testChat() {
        String chatId = UUID.randomUUID().toString();
        // 第一轮
        System.out.println("第一轮");
        String message = "你好，我是DD";
        String answer = loveApp.doChat(message, chatId);
        Assertions.assertNotNull(answer);
        // 第二轮
        System.out.println("第二轮");
        message = "我想让另一半（Casy）更爱我";
        answer = loveApp.doChat(message, chatId);
        Assertions.assertNotNull(answer);
        // 第三轮
        System.out.println("第三轮");
        message = "我的另一半叫什么来着？刚跟你说过，帮我回忆一下";
        answer = loveApp.doChat(message, chatId);
        Assertions.assertNotNull(answer);
    }

    @Test
    void doChatWithRag() {
        // 测试
        String chatId = UUID.randomUUID().toString();
        String message = "I'm married, but we haven't been very close since we got married. What should I do?";
        String answer =  loveApp.doChatWithRagForBaiduTranslation(message, chatId, "已婚", true);
        Assertions.assertNotNull(answer);

//        String chatId = UUID.randomUUID().toString();
//        String message = "我已经结婚了，但是婚后关系不太亲密，怎么办？";
//        String answer =  loveApp.doChatWithRagForContextualQuery(message, chatId);
//        Assertions.assertNotNull(answer);

//        String chatId = UUID.randomUUID().toString();
//        String message = "我已经结婚了，但是婚后关系不太亲密，怎么办？";
//        String answer =  loveApp.doChatWithRagForQueryFilterExpression(message, chatId);
//        Assertions.assertNotNull(answer);

//        String chatId = UUID.randomUUID().toString();
//        String message = "我已经结婚了，但是婚后关系不太亲密，怎么办？";
//        String answer =  loveApp.doChatWithRagForQueryRewriter(message, chatId);
//        Assertions.assertNotNull(answer);

//        String chatId = UUID.randomUUID().toString();
//        String message = "我已经结婚了，但是婚后关系不太亲密，怎么办？";
//        String answer =  loveApp.doChatWithRag(message, chatId);
//        Assertions.assertNotNull(answer);


//        message = "我目前处于什么婚因状态？你好好想想，我已经告诉你了";
//        answer =  loveApp.doChatWithRag(message, chatId);
//        Assertions.assertNotNull(answer);

//        String chatId = UUID.randomUUID().toString();
//        String message = "我是白羊座的，我的恋爱对象可能是什么样的？";
//        String answer =  loveApp.doChatWithRag(message, chatId);
//        Assertions.assertNotNull(answer);
    }

    public static void main(String[] args) {
        String chatId = UUID.randomUUID().toString();
        System.out.println("chatId: " + chatId);
    }

    @Test
    void doChatWithTools() {
        // 测试联网搜索问题的答案
        testMessage("帮我向 李四发一个入职offer邮件，他的邮箱是landun126228@163.com, 职位是产品经理，部门是产品部，到岗日期为2026-5-1, 年薪30万，地点为通州北关1232号");
//        testMessage("周末想带女朋友去上海约会，推荐几个适合情侣的小众打卡地？");
//
//        // 测试网页抓取：恋爱案例分析
//        testMessage("最近和对象吵架了，看看编程导航网站（codefather.cn）的其他情侣是怎么解决矛盾的？");
//
//        // 测试资源下载：图片下载
//        testMessage("直接下载一张适合做手机壁纸的星空情侣图片为文件");
//
//        // 测试终端操作：执行代码
//        testMessage("执行 Python3 脚本来生成数据分析报告");
//
//        // 测试文件操作：保存用户档案
//        testMessage("保存我的恋爱档案为文件");
//
//        // 测试 PDF 生成
//        testMessage("生成一份‘七夕约会计划’PDF，包含餐厅预订、活动流程和礼物清单");
    }

    private void testMessage(String message) {
        String chatId = UUID.randomUUID().toString();
        String answer = loveApp.doChatWithTools(message, chatId);
        Assertions.assertNotNull(answer);
    }

}
